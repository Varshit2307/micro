package com.javatechie.spring.mongo.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan("com.text.demo.controller")
@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class })
public class SpringMicroProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMicroProjectApplication.class, args);
	}

}
