package com.javatechie.spring.mongo.dao;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.javatechie.spring.mongo.entity.Student;

public interface StudentDAO extends MongoRepository<Student,Integer>{

	Student getById(int roll);
	
}